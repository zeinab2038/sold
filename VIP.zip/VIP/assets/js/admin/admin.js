jalaliDatepicker.startWatch({

    persianDigits: true,
    separatorChars: {
        date: '-'
    }
});
