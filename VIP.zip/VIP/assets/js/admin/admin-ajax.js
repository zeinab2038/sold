jQuery(document).ready(function ($) {
    $('.find-transaction').on('click', function (e) {
        e.preventDefault();
        let el = $(this);
        let t_id = el.data('id');
        jQuery.ajax({
            url: vipajax.ajaxurl,
            type: "POST",
            dataType: "JSON",
            data: {
                action: "findById",
                't_id': t_id,
                '_nonce': vipajax._nonce
            },
            beforeSend: function () {
            },
            success: function (response) {
                if (response.success) {
                    $('.t-price').val(response.price);
                    $('.t-plan-type').val(response.plan_type);
                    $('.t-order-number').val(response.order_number);
                    $('.t-ref-id').val(response.ref_id);
                    $('.t-status').val(response.status);
                    $('.t-id').val(response.id);

                }
            },
            error: function (error) {
                if (error) {
                    alert('خطا در دریافت اطاعات کاربر!!!');
                }
            },
            complete: function () {
            },
        });
    });
    $('.update-transaction').on('submit', function (e) {
        e.preventDefault();
        /* let el = $(this);*/
        let t_price = $('.t-price').val();
        let t_plan_type = $('.t-plan-type').val();
        let t_order_number = $('.t-order-number').val();
        let t_ref_id = $('.t-ref-id').val();
        let t_status = $('.t-status').val();
        let t_id = $('.t-id').val();
        jQuery.ajax({
            url: vipajax.ajaxurl,
            type: "POST",
            dataType: "JSON",
            data: {
                action: "updateById",
                't_price': t_price,
                't_plan_type': t_plan_type,
                't_order_number': t_order_number,
                't_ref_id': t_ref_id,
                't_status': t_status,
                't_id': t_id,
                '_nonce': vipajax._nonce
            },
            beforeSend: function () {
                $('.vip-loading-icon').addClass('active-loading');
            },
            success: function (response) {
                if (response.success) {
                    alert(response.message);
                }
            },
            error: function (error) {
                if (error) {
                    alert(error.responseJSON.message);
                }
            },
            complete: function () {
                $('.vip-loading-icon').removeClass('active-loading');
            },
        });
    });
    $('.add-transaction').on('submit', function (e) {
        e.preventDefault();
        /* let el = $(this);*/
        let plan_type = $('.plan-type').val();
        let first_name = $('.first-name').val();
        let last_name = $('.last-name').val();
        let email = $('.email').val();
        let order_number = $('.order-number').val();
        let ref_id = $('.ref-id').val();
        let price = $('.price').val();
        let status = $('.status').val();
        jQuery.ajax({
            url: vipajax.ajaxurl,
            type: "POST",
            dataType: "JSON",
            data: {
                action: "saveTransactionByAdmin",
                'price': price,
                'first_name': first_name,
                'last_name': last_name,
                'email': email,
                'plan_type': plan_type,
                'order_number': order_number,
                'ref_id': ref_id,
                'status': status,
                '_nonce': vipajax._nonce
            },
            beforeSend: function () {

            },
            success: function (response) {
                if (response.success) {
                   /* alert(response.message);*/
                    $('.show-message').show().addClass('uk-alert-success').removeClass('uk-alert-danger').text(response.message);
                }
            },
            error: function (error) {
                if (error) {
                    /*alert(error.responseJSON.message);*/
                    $('.show-message').show().addClass('uk-alert-danger').removeClass('uk-alert-success').text(error.responseJSON.message);
                }
            },
            complete: function () {

            },
        });
    });

})


