<?php

class Helper
{
    public static function accountType($type)
    {
        switch ($type) {
            case 1:
                return 'طلایی';
                breack;
            case 2:
                return 'نقره ای';
                breack;
            case 3:
                return 'برنزی';
                breack;
        }

    }
    //حذف صفرهای تومان
    public static function dropzero($price){
return rtrim($price,'0');
    }
    public static function benefit($benefits){
        $benefits=explode('|',$benefits);
        $item='';
        foreach ($benefits as $benefit){
            $item.='<li>'.$benefit.'</li>';
        }
        return $item;
    }
    public static function orderNumber(){
        return jdate('Ymd').rand(1000,9999);
    }
}
