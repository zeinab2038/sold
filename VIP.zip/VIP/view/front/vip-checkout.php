<?php
function vip_checkout()
{
    if(!isset($_POST['plan_id']) || !is_user_logged_in() || empty($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'])){
        wp_redirect(home_url());
    }
    var_dump(Session::get('user_plan_data'));
    ?>
    <div class="checkout-wrapper">
        <p class="checkout-title"> <?php echo Helper::accountType(Session::get('user_plan_data')['order_number']) ?>پرداخت جهت اکانت vip - پلن</p>
        <div class="order-details">
            <span>شماره سفارس<span
                        class="order-number"><?php echo Helper::orderNumber() ?></span></span>
            <span>تاریخ سفارش<span class="order-date"><?php echo jdate('d-m-Y') ?></span></span>
        </div>
        <div class="price-wrapper">
            <span>مبلغ قابل پرداخت  </span>
            <span class="price"><span><?php Session::get('user_plan_data')['price'] ?> هزار تومان</span></span>
        </div>
        <div class="pay">
            <form action="<?php echo htmlspecialchars(get_the_permalink())?>" method="post">
                <input type="submit" name="pay" value="پرداخت">
            </form>
        </div>
    </div>
<?php
    if(isset($_POST['pay'])){
        $transaction=new Transaction;
        $transaction->save(Session::get('user_plan_data'));
    }
}
add_shortcode('vip-checkout', 'vip_checkout');
