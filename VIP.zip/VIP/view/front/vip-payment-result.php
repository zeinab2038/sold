<?php
function vip_payment_result(){
    if(!is_user_logged_in() || empty($_GET['Status']) || $_GET['Status']!= 'OK'){
        wp_redirect(home_url());
    }
Payment::setter(Session::get('user_plan_data'));
Payment::payment_result();
?>
    <div class="checkout-wrapper">
        <p class="payment-title">رسید پرداخت جهت اکانت vip - پلن <?php echo Helper::accountType(Session::get('user_plan_data')['plan_type']) ?></p>
        <div class="order-details">

            <span>شماره سفارس<span
                    class="order-number"><?php echo Session::get('user_plan_data')['order_number'] ?></span></span>
            <span>تاریخ سفارش<span class="order-date"><?php echo jdate('d-m-Y') ?></span></span>
        </div>
        <div class="price-wrapper">
            <span>مبلغ پرداخت شده </span>
            <span class="price"><?php echo Session::get('user_plan_data')['price']?><span>هزار تومان</span></span>
        </div>
        <div class="pay-result">
            <div class="ref-number">
                <span>شماره تراکنش</span>
                <span><?php echo Payment::getRefID(); ?></span>
            </div>
            <a href="<?php echo site_url() ?>">بازگشت به سایت</a>
        </div>
    </div>
<?php
    Session::unset('user_plan_data');
}
add_shortcode('vip-payment-result','vip_payment_result');