<?php
if (!current_user_can('manage_options')) {
    return;
}
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['save-vip-setting'])) {
    if (isset($_POST['_nonce_add_vip_setting']) && !wp_verify_nonce($_POST['_nonce_add_vip_setting'], 'add_vip_setting')) {
        return false;
    }
    foreach ($_POST as $post) {
        if ($post == '') {
            FlashMessage::addMsg('تکمیل تمامی فیلدها الزامی می باشد!!!', 0);
        }
    }
    $data = [
        'merchant_id' => sanitize_text_field($_POST['merchant_id']),
        'gateway' => sanitize_text_field($_POST['gateway']),
        'checkout' => sanitize_text_field($_POST['checkout']),
        'callback_url' => sanitize_text_field($_POST['callback_url'])
    ];
    $save = update_option('_vip_setting', $data);
    if ($save) {
        FlashMessage::addMsg('اطلاعات مورد نظر با موفقیت ثبت گردید.', 1);
    } else {
        FlashMessage::addMsg('خطا در ثبت اطلاعات!!!', 0);
    }
}
?>
<div class="uk-container uk-container-xlarge">
    <div class="uk-flex uk-flex-middle uk-margin-bottom">
        <h3 class="uk-margin-top"><?php echo esc_html(get_admin_page_title()) ?></h3>
    </div>
    <?php echo FlashMessage::showMsg() ?>
    <form action="" method="post" class="uk-grid-small" uk-grid>

        <div class="uk-width-1-4@s">
            <label class="uk-margin-bottom" for="merchant">مرچنت آی دی </label>
            <input id="merchant" class="uk-input" type="text" name="merchant_id"
                   value="<?php echo get_option('_vip_setting')['merchant_id'] ? get_option('_vip_setting')['merchant_id'] : ''?>"
                   placeholder="مرچنت آی دی درگاه پرداخت ...">
        </div>
        <div class="uk-width-1-4@s">
            <label class="uk-margin-bottom" for="gate-connect">نامک برگه رابط درگاه پرداخت</label>
            <input id="gate-connect" class="uk-input" type="text" name="gateway"
                   value="<?php echo get_option('_vip_setting')['gateway'] ? get_option('_vip_setting')['gateway'] : ''?>"
                   placeholder="نامک برگه رابط درگاه پرداخت...">
        </div>
        <div class="uk-width-1-4@s">
            <label class="uk-margin-bottom" for="gate-connect">نامک برگه اتصال به درگاه پرداخت </label>
            <input id="gate-connect" class="uk-input" type="text" name="checkout"
                   value="<?php echo get_option('_vip_setting')['checkout'] ? get_option('_vip_setting')['checkout'] : ''?>"
                   placeholder="نامک برگه اتصال به درگاه پرداخت ...">
        </div>
        <div class="uk-width-1-4@s">
            <label class="uk-margin-bottom" for="gate-return">نامک برگه بازگشت از درگاه پرداخت</label>
            <input id="gate-return" class="uk-input" type="text" name="callback_url"
                   value="<?php echo get_option('_vip_setting')['callback_url'] ? get_option('_vip_setting')['callback_url'] : ''?>"
                   placeholder="نامک برگه بازگشت از درگاه پرداخت ...">
        </div>

        <div class="uk-width-1-4@s">
            <label class="uk-margin-bottom">&nbsp;&nbsp;&nbsp;</label>
            <button type="submit" name="save-vip-setting" class="uk-input uk-button uk-button-primary">ثبت</button>
            <?php wp_nonce_field('add_vip_setting', '_nonce_add_vip_setting'); ?>
        </div>
    </form>
</div>