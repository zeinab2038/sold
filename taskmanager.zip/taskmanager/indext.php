<?php
include "tpl1/tpl-index.php";
include "assets1/css/style.css";