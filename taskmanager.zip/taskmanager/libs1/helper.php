<?php
function diepage($msg){
    echo $msg;
    die();
}