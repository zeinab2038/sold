<?php
include  "config.php";
echo $database;



