<?php
/*$database=(object)[
    'host'=>'localhost',
    'user'=>'root',
    'pass'=>'',
    'db'=>'todolist'
];*/

class aa{
  public static function aa()
  {
      echo "salan";
  }
}