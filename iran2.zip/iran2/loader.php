<?php
include "App/iran.php";
/*spl_autoload_register(function($class){
    $class_file ="C:/xampp/htdocs/Iran/".$class.".php";
    if(!(file_exists($class_file) && is_readable($class_file)))
        die ("$class not");
        include_once $class_file;
    
    });*/
    include "App/services/cityserver.php";
    include "App/utilities/Responce.php";