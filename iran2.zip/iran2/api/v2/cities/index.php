<?php
include "../../../loader.php";
use App\services\cityserver;
use App\utilities\Responce;
//کد اضافه کردن شهر
$request_body = json_decode(file_get_contents('php://input'),true);
$request_method = $_SERVER['REQUEST_METHOD'];
switch($request_method){
    case 'GET':
        $province_id=$_GET['province_id'] ?? null;
        $request_data=[
            'province_id'=> $province_id
        ];
        $city_serviece=new cityserver();
        $valid=new ProvinceValidator();
        if(!$valid->is_valid_province($province_id)){
        echo Responce::respond(['not'],Responce::HTTP_OK);
        }
        else
        {
            $response=$city_serviece->getCities($request_data);
            echo Responce::respond($response,Responce::HTTP_OK);
        }
           
        break;
        case 'POST':
           
            if(!isValidCity($request_body))
            Responce::respond(['Invalid City Data ..'],Responce::HTTP_NOT_ACCEPTABLE);
        $response = $city_serviece->createCity($request_body);
        Responce::respond($response,Responce::HTTP_CREATED);
        break;
     case 'DELETE':
        $city_id=$_GET['city_id'] ?? null;
        $request_data=[
            'city_id'=> $city_id
        ];
if(is_null($request_data) || !is_numeric($request_data)){
    echo Responce::respond(['Invalid'],Responce::HTTP_METHOD_NOT_ALLOWED);
}
        $city_serviece=new cityserver();
        $result= $city_serviece->deleteCity($request_data);
          break;
    case 'PUT':
        $city_serviece=new cityserver();
        [$city_id,$name]=[$request_body['city_id']];
       $result= $city_serviece->deleteCity($city_id,$name);
       Responce::respond($result,Responce::HTTP_OK);
            break;
  
      default:
      echo Responce::respond(['Invalid'],Responce::HTTP_METHOD_NOT_ALLOWED);

}
