<?php
include "../../../loader.php";
use App\services\cityserver;
use App\utilities\Responce;
//کد اضافه کردن شهر
$request_body = json_decode(file_get_contents('php://input'),true);
$request_method = $_SERVER['REQUEST_METHOD'];
switch($request_method){
    case 'GET':
        $province_id=$_GET['province_id'] ?? null;
        $request_data=[
            'province_id'=> $province_id,
           ' page'=>(int)$_GET['page'] ?? null,
          'pagesize' => (int)$_GET['pagesize'] ?? null,
          'field' => (int)$_GET['field'] ?? '*',
        ];
       
        $city_serviece=new cityserver();
            $response=$city_serviece->getCities($request_data);
           //  if(empty($response)){
          // echo Responce::respond(['Invalid City Data ..'],Responce::HTTP_NOT_ACCEPTABLE);
       // }
            echo Responce::respond($response,Responce::HTTP_OK);
        break;

        case 'POST':
        $response = $city_serviece->createCity($request_body);
        Responce::respond($response,Responce::HTTP_CREATED);
        break;
     case 'DELETE':
        $city_id=$_GET['city_id'] ?? null;
        $request_data=[
            'city_id'=> $city_id
        ];
if(is_null($request_data) || !is_numeric($request_data)){
    echo Responce::respond(['Invalid'],Responce::HTTP_METHOD_NOT_ALLOWED);
}
        $city_serviece=new cityserver();
        $result= $city_serviece->deleteCity($request_data);
          break;
    case 'PUT':
        $city_serviece=new cityserver();
        [$city_id,$name]=[$request_body['city_id']];
       $result= $city_serviece->deleteCity($city_id,$name);
       Responce::respond($result,Responce::HTTP_OK);
            break;
      default:
      echo Responce::respond(['Invalid'],Responce::HTTP_METHOD_NOT_ALLOWED);

}
