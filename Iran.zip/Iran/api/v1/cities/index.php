<?php
include "../../../loader.php";
use \App\services\cityserver;
use \App\utilities\Responce;
$get= new cityserver();
$result = $get->getCities((object)[1,2,33,444,55]);
echo Responce::respond($result,Responce::HTTP_OK);