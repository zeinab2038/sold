<?php
namespace App\services;

class cityserver{
function getCities($data){
    return $data;
}
}