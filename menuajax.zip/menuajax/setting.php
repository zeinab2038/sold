<html lang="fa">
<h1>فایل آپلودر</h1>
<div style="width: 100%;height: 100%;background-color: #fff;padding: 3px">
    <form id="form" action="" method="post">
        <input type="text" name="login_user" id="first_name">
        <input type="submit" id="login" name="submit" value="ذخیره" style="margin-top: 20px;">
    </form>
</div>
