<?php
/**
 * Plugin Name: asfadsfadf
 * Description: Add a register via sms form widget.
 * Version:     1.2.0
 * Text Domain: elementor-sms-widget
 */

session_start();

$url = defined( 'ABSPATH' ) || exit;
define('IR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('IR_PLUGIN_URL', plugin_dir_url(__FILE__));

if (is_admin()) {
    wp_register_script('dashboard-js', IR_PLUGIN_URL . 'menu.js', ['jquery'], '1.0.0', '');
    wp_enqueue_script('dashboard-js');
}

// Includes
include_once 'menu.php';
include_once 'sss.php';

function elementor_sms_widget_text_domain() {
    load_plugin_textdomain(
        'elementor-sms-widget',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages/'
    );
}
add_action( 'plugins_loaded', 'elementor_sms_widget_text_domain' );
