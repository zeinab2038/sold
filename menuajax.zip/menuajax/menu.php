<?php
add_action( 'admin_menu', 'setting');

function setting(){
    add_menu_page(
        'setting',
        'setting',
        'manage_options',
        'setting_SMS',
        'setting_Ui'
    );
}

function setting_Ui(){
    include_once 'setting.php';
}