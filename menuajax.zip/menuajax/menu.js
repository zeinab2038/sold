(function($) {
    $('body').on('click','#login',function(e) {
        e.preventDefault();
        let first_name = $('#first_name').val();
        $.ajax({
            url:  'admin-ajax.php',
            type: "post",
            data: {
                action: "add_product",
                login_user: first_name,
            },

            beforeSend: function() {
            },
            success: function(response) {
                // کد پس از دریافت پاسخ موفق
            },
            error: function(error) {
                // کد پس از بروز خطا
            },
            complete: function() {
                // کد بعد از اتمام درخواست
            },
        });
    });
})(jQuery);