<?php
add_action('wp_ajax_add_product', 'add_product');
function add_product()
{
    if (!wp_verify_nonce($_POST['nonce'])) {
        die('access denied !!!');
    }
    update_option('_template_id', $_POST['login_user']);
    wp_ir_validate_code($_POST['login_user']);
}

function wp_ir_validate_code($code)
{
    if ($code == '') {
        wp_send_json([
            'error' => true,
            'message' => 'لطفا شماره موبایل معتبر وارد نمایید!'
        ], 403);
    }
}

