jQuery(document).ready(function($){
    console.log('');
    $('#send_code').on('click',function(e){
        e.preventDefault();
        let el = $(this);
        let user_phone=$('.user_phone').val();
        $.ajax({
            url: lr_ajax.ajaxurl,
            type: "POST",
            dataType: "JSON",
            data: {
                action: "IR_el_auth_verify_verification_code",
                user_phone: user_phone ,
                _nonce: lr_ajax._nonce
            },
            beforeSend: function () {
            },
            success: function (response) {
            },
            error: function (error) {
                if(error.responseJSON.error){
                    alert(error.responseJSON.message)
                }
            },
            complete: function () {
            },
        });
    });
    $('body').on('click','#verify_code',function(e){
        e.preventDefault();
        let el = $(this);
        let verification_code = $('.verification_code').val();
        $.ajax({
            url: lr_ajax.ajaxurl,
            type: "POST",
            dataType: "JSON",
            data: {
                action: "wp_ls_auth_verify_verification_code",
                verification_code: verification_code ,
                _nonce: lr_ajax._nonce
            },
            beforeSend: function () {
                $('#verify_code').html('<div class="lds-facebook"><div></div><div></div><div></div></div>');
            },
            success: function (response) {
                $('#get_user_phone').html('<div id="register_form"> <div class="form-group"><label>نام و نام خانوادگی*</label> <input type="text" class="form-control display_name" value=""  placeholder="نام و نام خانوادگی..."> </div> <div class="form-group"><label>ایمیل*</label><input type="email..." class="form-control email" value="" placeholder="email..." dir="ltr"></div> <div class="form-group"><label>رمز عبور*</label><input type="text" class="form-control password" value=""></div> <div class="form-group"> <a href="" class="btn btn_apply w-100 " id="register_user">ثبت نام</a> </div></div>');
            },
            error: function (error) {
                if(error.responseJSON.error){
                    alert(error.responseJSON.message)
                }
            },
            complete: function () {

            },
        });
    });
    $('body').on('click','#register_user',function(e){
        e.preventDefault();
        let el = $(this);
        let display_name = $('.display_name').val();
        let email= $('.email').val();
        let password = $('.password').val();
        $.ajax({
            url: lr_ajax.ajaxurl,
            type: "POST",
            dataType: "JSON",
            data: {
                action: "wp_ir_register_user",
                display_name : display_name ,
                email:email,
                password:password,
                _nonce: lr_ajax._nonce
            },
            beforeSend: function () {
            },
            success: function (response) {
            },
            error: function (error) {
                if(error.responseJSON.error){
                    alert(error.responseJSON.message)
                }
            },
            complete: function () {
            },
        });
    });
})