(function( $ ) {

	var SMSWidgetdHandler = function( $scope, $ ) {
		$('body').on('click','#send_code',function (e) {
			e.preventDefault();
			let user_phone=$('.user_phone').val();
			var step = $( this ).data( 'step' );
			$.ajax({
				url: lr_ajax.ajaxurl,
				type: "POST",
				dataType: "JSON",
				data: {
					action: "wp_ir_auth_send_verification_code",
					user_phone: user_phone ,
					_nonce: lr_ajax._nonce
				},
				beforeSend: function () {
				},
				success: function (response) {
					if ( step == 1 || step == 2 ) {
						$scope.find( '.elementor-sms-ind' + step ).removeClass( 'elementor-sms-active' );
						$scope.find( '.elementor-sms-step' + step ).slideUp( 'slow' );
						step++;
						$scope.find( '.elementor-sms-step' + step ).slideDown( 'slow' );
						$scope.find( '.elementor-sms-ind' + step ).addClass( 'elementor-sms-active' );
					}
				},
				error: function (error) {
					if(error.responseJSON.error){
						alert(error.responseJSON.message)
					}
				},
				complete: function () {

				},

			});
		});
		$('body').on('click','#verify_code',function (e) {
			e.preventDefault();
			let verification_code = $('.verification_code').val();
			var step = $(this).data('step');
			$.ajax({
				url: lr_ajax.ajaxurl,
				type: "POST",
				dataType: "JSON",
				data: {
					action: "wp_ir_auth_verify_verification_code",
					verification_code: verification_code,
					_nonce: lr_ajax._nonce
				},
				beforeSend: function () {
				},
				success: function (response) {
					if (step == 1 || step == 2) {
						$scope.find('.elementor-sms-ind' + step).removeClass('elementor-sms-active');
						$scope.find('.elementor-sms-step' + step).slideUp('slow');
						step++;
						$scope.find('.elementor-sms-step' + step).slideDown('slow');
						$scope.find('.elementor-sms-ind' + step).addClass('elementor-sms-active');
					}
				},
				error: function (error) {
					if (error.responseJSON.error) {
						alert(error.responseJSON.message)
					}
				},
				complete: function () {

				},

			});
		});
		$('body').on('click','#register_user',function (e) {
			e.preventDefault();
			let el = $(this);
			let display_name = $('.first_name').val();
			let email = $('.email').val();
			let password = $('.password').val();
					$.ajax({
						url: lr_ajax.ajaxurl,
						type: "POST",
						dataType: "JSON",
						data: {
							action: "wp_ir_register_user",
							display_name:display_name,
							email:email,
							password:password,
							_nonce: lr_ajax._nonce
				},
				beforeSend: function () {
				},
				success: function (response) {
					if(response.success){
						$.toast({
							/*    heading: 'خطا',*/
							text: response.message,
							icon: 'success',
							loader: true,        // Change it to false to disable loader
							loaderBg: '#5a5a5a',  // To change the background
							textAlign: 'right',
							bgColor: '#66BB6A',
							hideAfter: 3000,
						})
						setTimeout(function () {
							window.location.href = "/";
						}, 3000);
					}
				},
				error: function (error) {
					if (error.responseJSON.error) {
						/*    alert(error.responseJSON.message);*/
						/*alert(error.responseJSON.message);*/
						$.toast({
							/*    heading: 'خطا',*/
							text: error.responseJSON.message,
							icon: 'error',
							loader: true,        // Change it to false to disable loader
							loaderBg: '#5a5a5a',  // To change the background
							textAlign: 'right',
							bgColor: '#FF1356',
							hideAfter: 3000,
						})
					}
				},
				complete: function () {

				},

			});
		});
	};

	$( window ).on( 'elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/sms-widget.default', SMSWidgetdHandler );
	} );

})( jQuery );
