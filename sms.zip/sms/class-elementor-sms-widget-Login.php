<?php

use \Elementor\Core\Kits\Documents\Tabs\Global_Colors;

defined( 'ABSPATH' ) || exit;

class Elementor_SMS_Widget extends \Elementor\Widget_Base {
	
	public function __construct($data = [], $args = null) {
		parent::__construct( $data, $args );
		wp_register_style( 'elementor-sms-widget-style', plugin_dir_url(__FILE__) . 'assets/sms-widget.css');
		wp_register_script( 'elementor-sms-widget-script', plugin_dir_url(__FILE__) . 'assets/sms-widget.js', [ 'jquery' ]  );
	}



	public function get_name() {
		return 'sms-widget';
	}


	public function get_title() {
		return esc_html__( 'SMS Widget', 'elementor-sms-widget' );
	}


	public function get_icon() {
		return ' eicon-form-horizontal';
	}


	public function get_categories() {
		return [ 'general' ];
	}


	public function get_keywords() {
		return [ 'sms', 'register' ];
	}


	public function get_style_depends() {
		return [ 'elementor-sms-widget-style' ];
	}


	public function get_script_depends() {
		return [ 'elementor-sms-widget-script' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'section_labels',
			[
				'label' => esc_html__( 'Labels', 'elementor-sms-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'mobile',
			[
				'label' => esc_html__( 'Mobile', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Mobile', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'verification-code',
			[
				'label' => esc_html__( 'Verification Code', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Verification Code', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'first-name',
			[
				'label' => esc_html__( 'First Name', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'First Name', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'last-name',
			[
				'label' => esc_html__( 'Last Name', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Last Name', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'password',
			[
				'label' => esc_html__( 'Password', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Password', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'step1-btn',
			[
				'label' => esc_html__( 'Step 1 Button', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Send verification code', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'step2-btn',
			[
				'label' => esc_html__( 'Step 2 Button', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Verify', 'elementor-sms-widget' ),
			]
		);
		
		$this->add_control(
			'step3-btn',
			[
				'label' => esc_html__( 'Step 3 Button', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Register', 'elementor-sms-widget' ),
			]
		);

		$this->end_controls_section();

		$this->add_container_controls();
		$this->add_steps_controls();
		$this->add_inputs_controls();
		$this->add_buttons_controls();
	}


	private function add_steps_controls() {

		$this->start_controls_section(
			'steps_style',
			[
				'label' => esc_html__( 'Steps Indicator', 'elementor-sms-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'steps_border',
				'selector' => '{{WRAPPER}} .elementor-sms-steps',
			]
		);

		$this->add_responsive_control(
			'steps_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-steps' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'steps_width',
			[
				'label' => esc_html__( 'Width', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 800,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 230,
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-steps' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'size_color',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);


		$this->start_controls_tabs( 'tabs_steps_style' );

		$this->start_controls_tab(
			'tab_steps_normal',
			[
				'label' => esc_html__( 'Normal', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'steps_text_color',
			[
				'label' => esc_html__( 'Text Color', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-normal' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'steps_background',
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .elementor-sms-normal',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'global' => [
							'default' => Global_Colors::COLOR_ACCENT,
						],
					],
				],
			]
		);
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_steps_active',
			[
				'label' => esc_html__( 'Active', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'steps_active_color',
			[
				'label' => esc_html__( 'Text Color', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-active' => 'color: {{VALUE}} !important;',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'steps_background_active',
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .elementor-sms-active',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'global' => [
							'default' => Global_Colors::COLOR_PRIMARY,
						],
					],
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}


	private function add_inputs_controls() {

		$this->start_controls_section(
			'section_inputs_style',
			[
				'label' => esc_html__( 'Inputs', 'elementor-sms-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'inputs_label_color',
			[
				'label' => esc_html__( 'Label Color', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-container label' => 'color: {{VALUE}};',
				],
				'global' => [
					'default' => Global_Colors::COLOR_TEXT,
				],
			]
		);

		$this->add_control(
			'inputs_label_margin',
			[
				'label' => esc_html__( 'Label Margin Bottom', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 30,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-container label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'label_inputs',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'inputs_width',
			[
				'label' => esc_html__( 'Fields Width', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 800,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 250,
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-container input' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementor-sms-input-group' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementor-sms-mobile-input' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'inputs_margin',
			[
				'label' => esc_html__( 'Fields Margin', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-input-group' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'px',
					'top' => 8,
					'right' => 0,
					'bottom' => 15,
					'left' => 0,
				],
			]
		);

		$this->add_control(
			'inputs_color',
			[
				'label' => esc_html__( 'Fields Color', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-container input' => 'color: {{VALUE}};',
					'{{WRAPPER}} .elementor-sms-mobile-input span' => 'color: {{VALUE}};',
				],
				'global' => [
					'default' => Global_Colors::COLOR_TEXT
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'inputs_border',
				'selector' => '{{WRAPPER}} .elementor-sms-border-input',
			]
		);

		$this->add_responsive_control(
			'inputs_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-border-input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'inputs_outline_width',
			[
				'label' => esc_html__( 'Outline Width', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-container input:focus' => 'outline-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementor-sms-mobile-input:focus-within' => 'outline-width: {{SIZE}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'px',
					'size' => 1,
				],
			]
		);

		$this->add_control(
			'inputs_outline_color',
			[
				'label' => esc_html__( 'Outline Color', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-container input:focus' => 'outline-color: {{VALUE}};',
					'{{WRAPPER}} .elementor-sms-mobile-input:focus-within' => 'outline-color: {{VALUE}};',
				],
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
			]
		);

		$this->end_controls_section();
	}

	
	private function add_container_controls() {

		$this->start_controls_section(
			'section_container_style',
			[
				'label' => esc_html( 'Container', 'elementor-sms-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'container_typography',
				'selector' => '{{WRAPPER}} .elementor-sms-container',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'container_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .elementor-sms-container',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'container_border',
				'selector' => '{{WRAPPER}} .elementor-sms-container',
			]
		);

		$this->add_responsive_control(
			'container_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'container_box_shadow',
				'selector' => '{{WRAPPER}} .elementor-sms-container',
			]
		);
		
		$this->add_control(
			'container_max_width',
			[
				'label' => esc_html__( 'Max Width', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 400,
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-container' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	private function add_buttons_controls() {

		$this->start_controls_section(
			'section_buttons_style',
			[
				'label' => esc_html__( 'Buttons', 'elementor-sms-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'buttons_pos',
			[
				'label' => esc_html__( 'Position', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'textdomain' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'textdomain' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'textdomain' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .elementor-sms-btn' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'buttons_text_shadow',
				'selector' => '{{WRAPPER}} .elementor-button',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'buttons_box_shadow',
				'selector' => '{{WRAPPER}} .elementor-button',
			]
		);

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_buttons_normal',
			[
				'label' => esc_html__( 'Normal', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'buttons_text_color',
			[
				'label' => esc_html__( 'Text Color', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'fill: {{VALUE}}; color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'buttons_background',
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .elementor-button',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'global' => [
							'default' => Global_Colors::COLOR_ACCENT,
						],
					],
				],
			]
		);
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => esc_html__( 'Hover', 'elementor-sms-widget' ),
			]
		);

		$this->add_control(
			'buttons_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-button:hover, {{WRAPPER}} .elementor-button:focus' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'buttons_background_hover',
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .elementor-button:hover, {{WRAPPER}} .elementor-button:focus',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'buttons_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-button:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => esc_html__( 'Hover Animation', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'buttons_border',
				'selector' => '{{WRAPPER}} .elementor-button',
			]
		);

		$this->add_responsive_control(
			'buttons_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'elementor-sms-widget' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
 
		$this->end_controls_section();
	}


	protected function render() {
		$settings = $this->get_settings_for_display();
?>
			<div class="elementor-sms-container">
				<div class="elementor-sms-steps">
					<span class="elementor-sms-ind1 elementor-sms-normal elementor-sms-active">1</span>
					<span class="elementor-sms-ind2 elementor-sms-normal">2</span>
					<span class="elementor-sms-ind3 elementor-sms-normal">3</span>
				</div>
				<form class="elementor-sms-form" action="" method="post">
					<div class="elementor-sms-step1">
						<div class="elementor-sms-input-group">
							<label for="elementor-sms-mobile"><?= $settings['mobile']; ?></label>
							<div class="elementor-sms-mobile-input elementor-sms-border-input">
								<span class="elementor-sms-mobile-prefix">+98</span>
								<input type="tel" id="elementor-sms-mobile" />
							</div>
						</div>


						<div class="elementor-sms-input-group elementor-sms-btn">
						<a href="#" data-step="1" class="elementor-button <?= empty( $settings['hover_animation'] ) ? '' : 'elementor-animation-' . $settings['hover_animation']; ?>"><?= $settings['step1-btn']; ?></a>
						</div>
					</div>

					<div class="elementor-sms-step2">
						<div class="elementor-sms-input-group">
							<label for="elementor-sms-verification"><?= $settings['verification-code']; ?></label>
							<div class="elementor-sms-verification-input">
								<input type="num" id="elementor-sms-verification" maxlength="1" class="elementor-sms-border-input" />
								<input type="num" maxlength="1" class="elementor-sms-border-input" />
								<input type="num" maxlength="1" class="elementor-sms-border-input" />
								<input type="num" maxlength="1" class="elementor-sms-border-input" />
							</div>
						</div>
						<div class="elementor-sms-input-group elementor-sms-btn">
						<a href="#" data-step="2" class="elementor-button <?= empty( $settings['hover_animation'] ) ? '' : 'elementor-animation-' . $settings['hover_animation']; ?>"><?= $settings['step2-btn']; ?></a>
						</div>
					</div>

					<div class="elementor-sms-step3">
						<div class="elementor-sms-input-group">
							<label for="elementor-sms-first-name"><?= $settings['first-name']; ?></label>
							<input type="text" id="elementor-sms-first-name" class="elementor-sms-border-input" />
						</div>

						<div class="elementor-sms-input-group">
							<label for="elementor-sms-last-name"><?= $settings['last-name']; ?></label>
							<input type="text" id="elementor-sms-last-name" class="elementor-sms-border-input" />
						</div>

						<div class="elementor-sms-input-group">
							<label for="elementor-sms-password"><?= $settings['password']; ?></label>
							<input type="password" id="elementor-sms-password" class="elementor-sms-border-input" />
						</div>

						<div class="elementor-sms-input-group elementor-sms-btn">
						<a href="#" id="register_user" data-step="3" class="elementor-button <?= empty( $settings['hover_animation'] ) ? '' : 'elementor-animation-' . $settings['hover_animation']; ?>"><?= $settings['step3-btn']; ?></a>
						</div>
					</div>
				</form>
			</div>
<?php
	}
}
