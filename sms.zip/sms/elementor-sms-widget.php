<?php
/**
 * Plugin Name: Elementor SMS Widget
 * Description: Add a register via sms form widget.
 * Version:     1.0.0
 * Text Domain: elementor-sms-widget
 */
    session_start();

defined( 'ABSPATH' ) || exit;
define('IR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('IR_PLUGIN_URL', plugin_dir_url(__FILE__));


//js
function wp_lr_register_assets_admin()
{

    wp_register_style( 'elementor-sms-widget-style', plugin_dir_url(__FILE__) . 'assets/css/sms-widget.css');
    wp_enqueue_script('elementor-sms-widget-style');
}
function wp_lr_register_assets()
{
    wp_enqueue_script('lr-ajax-js', IR_PLUGIN_URL . 'assets/js/sms-widget.js', ['jquery'], '1.0.0', 'true');
    wp_localize_script('lr-ajax-js', 'lr_ajax', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        '_nonce' => wp_create_nonce()
    ]);
    wp_register_style( 'elementor-sms-widget-style', plugin_dir_url(__FILE__) . 'assets/css/sms-widget.css');
    wp_enqueue_script('elementor-sms-widget-style');
}
add_action('wp_enqueue_scripts', 'wp_lr_register_assets');
add_action('admin_enqueue_scripts', 'wp_lr_register_assets_admin');
//inclueds
include_once '_inc/MeliPayamak.php';
include_once 'elementor-sms-widget.php';
include_once '_inc/register.php';


function register_sms_widget( $widgets_manager ) {

	require_once( IR_PLUGIN_DIR . 'class-elementor-sms-widget-register.php' );

	$widgets_manager->register( new \Elementor_SMS_Widget() );

}
add_action( 'elementor/widgets/register', 'register_sms_widget' );


function elementor_sms_widget_text_domain() {
	load_plugin_textdomain(
		'elementor-sms-widget',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'elementor_sms_widget_text_domain' );
