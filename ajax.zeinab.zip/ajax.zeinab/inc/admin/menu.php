<?php
add_action('admin_menu','ajax_plugin_menu');
function ajax_plugin_menu(){
	add_menu_page('لیست محصولات','لیست محصولات','manage_options','wpa_product_home','ajax_menu_content',);
}
function ajax_menu_content(){
	include_once WPA_PLUGIN_VIEW.'admin/product-list.php';
}