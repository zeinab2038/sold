<h3>لیست محصولات</h3>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12">
			<table class="table sc">
				<thead>
				<tr>
					<th scope="col">#</th>
					<th scope="col">نام محصول</th>
					<th scope="col">برند</th>
					<th scope="col">مدل</th>
					<th scope="col">قیمت</th>
					<th scope="col">وضعیت</th>
					<th scope="col">ادیت</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<th scope="row">1</th>
					<td>Mark</td>
					<td>Otto</td>
					<td>@mdo</td>
					<td>@mdo</td>
					<td>@mdo</td>
					<td>@mdo</td>
					<td><i class="bi bi-volume-down-fill"></i>
                    </td>
				</tr>
				<tr>
					<td>Mark</td>
					<td>Otto</td>
					<td>@mdo</td>
					<td>@mdo</td>
					<td>@mdo</td>
					<td>@mdo</td>
					<td>@mdo</td>
				</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
