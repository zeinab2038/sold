<?php
/**
 * Plugin Name: ایجکس
 * Plugin URI: https://iranelEmentor.com
 * Description: Extend Elementor Page Builder with 70+ Creative Widgets and exciting extensions.
 * Version: 2.9.20
 * Author: iranelEmentor
 * Author URI: http://iranelEmentor.com
 * License: GNU General Public License v2.0
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: powerpack
 * Domain Path: /languages
 * Elementor tested up to: 3.14.0
 * Elementor Pro tested up to: 3.14.0
 */

defined('ABSPATH') || exit;
define('LR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LR_PLUGIN_URL', plugin_dir_url(__FILE__));
const WPA_PLUGIN_INC=LR_PLUGIN_DIR.'inc/';
const WPA_PLUGIN_VIEW=LR_PLUGIN_DIR.'view/';
const WPA_PLUGIN_ASSETS_DIR=LR_PLUGIN_DIR.'assets/';
const WPA_PLUGIN_ASSETS_URL=LR_PLUGIN_URL.'assets/';
function wpbootstrap_enqueue_styles() {
	wp_register_style('bootstrap-5', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.rtl.min.css', '', '5.2.0');
	wp_register_style('main-style', plugins_url('wp-ajax/assets/css/main-style.css'), '1.0.0');
	wp_register_style('bootstrap-icon', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css', '', '5.2.0');
	wp_enqueue_style('bootstrap-5');
	wp_enqueue_style('bootstrap-icon');
	wp_enqueue_style('main-style');
}
add_action('wp_enqueue_scripts', 'wpbootstrap_enqueue_styles');
include_once 'inc/admin/menu.php';
