<?php
/*
Plugin Name:  کاربران
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: کاربران
Author: وحید صالحی
Version: 2.0.0
License: GPLv2 or later
Author URI: http://develop-wp.local
*/
defined('ABSPATH') || exit;
define('WL_PLUGIN_DIR',plugin_dir_path(__FILE__));
define('WL_PLUGIN_URL',plugin_dir_url(__FILE__));
const WL_PLUGIN_INC = WL_PLUGIN_DIR . '_inc/';
const WL_PLUGIN_VIEW = WL_PLUGIN_DIR . 'view/';
const WL_PLUGIN_ASSETS = WL_PLUGIN_DIR . 'assets/';
include_once (WL_PLUGIN_INC.'admin/menus.php');
add_action( 'user_register', 'myplugin_registration_save', 10, 1 );
