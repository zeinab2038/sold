<?php
$user=get_user_by('id',$_GET['id']);

?>
<div class="wrap">
    <h1>ویرایش</h1>
    <form action="<?php echo esc_url($_SERVER['PHP_SELF']).'?page=user_list&action=update&id='.$_GET['id']?>" method="post">
        <input type="text" name="username" value="<?php echo $user->user_login ?>" placeholder="نام کاربری ...">
        <input type="text" name="user_email" value="<?php echo $user->user_email ?>" placeholder="ایمیل">
        <input type="text" name="tel"  value="<?php echo get_user_meta($_GET['id'],'_phone',true);  ?>" placeholder="شماره موبایل کاربر">
        <input type="submit" name="update-user" value="ویرایش" >
    </form>
</div>