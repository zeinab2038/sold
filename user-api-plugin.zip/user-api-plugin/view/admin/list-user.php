<div class="wrap">
    <h1>لیست کاربران</h1>
    <table>
        <thead>
        <tr>
            <th>آی دی</th>
            <th>نام کاربری</th>
            <th>ایمیل</th>
            <th>نام نمایشی</th>
            <th>تلفن</th>
            <th>عملیات</th>

        </tr>
        <tbody>
        <?php
        $users=get_users();
        foreach ($users as $user):

            ?>
            ?>
            <tr>
                <td><?php echo $user->ID ?></td>
                <td><?php echo $user->user_login ?></td>
                <td><?php echo $user->user_email ?></td>
                <td><?php echo $user->display_name ?></td>
                <td><?php echo get_user_meta($user->ID,'_phone',true) ?></td>
                <td><a href="<?php  echo $_SERVER['REQUEST_URI'].'&action=update'.'&id='.$user->ID ?>" class="dashicons dashicons-edit"></a>
                    <a href="<?php echo $_SERVER['REQUEST_URI'].'&action=delete&'.'id='.$user->ID ?> " class="dashicons dashicons-trash"></a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        </thead>
    </table>
</div>
