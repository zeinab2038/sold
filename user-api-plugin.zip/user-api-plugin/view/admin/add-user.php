
<div class="wrap">
    <h1>افزودن کاربر VIP</h1>
    <form action="<?php echo esc_url($_SERVER['PHP_SELF']).'?page=manage_user'?>" method="post">
        <input type="text" name="username" placeholder="نام کاربری ...">
        <input type="text" name="user_email" placeholder="ایمیل">
        <input type="text" name="tel" placeholder="شماره موبایل کاربر">
        <input type="submit" name="submit-user" value="افزودن کاربر جدید" >
    </form>
</div>
