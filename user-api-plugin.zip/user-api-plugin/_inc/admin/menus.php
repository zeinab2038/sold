<?php
add_action('admin_menu', 'wl_register_menus');

function wl_register_menus()
{
    add_menu_page(
        'کابر',
        'کاربر',
        'manage_options',
        'wl_home'
	);
    add_submenu_page(
        'wl_home',
        'مدیریت کاربران',
        'مدیریت کاربران',
        'manage_options',
        'manage_user',
        'manage_user'
	);
    add_submenu_page(
        'wl_home',
        'لیست کاربران',
        'لیست کاربران',
        'manage_options',
        'list_user',
        'list_user'
    );

}
function manage_user(){
    include_once (WL_PLUGIN_VIEW.'admin/add-user.php');
    include_once (WL_PLUGIN_INC.'admin/add-user.php');

}
function list_user(){
    if (isset($_GET['action']) && isset($_GET['id'])) {
        switch ($_GET['action']){
            case 'delete':
               // include WL_PLUGIN_INC.'admin/update-user.php';
                break;
            case 'update':
                include WL_PLUGIN_INC.'admin/update-user.php';
                include WL_PLUGIN_VIEW.'admin/update-user.php';
                return;

        }

    }

    include WL_PLUGIN_VIEW.'admin/list-user.php';

}