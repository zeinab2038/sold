<?php
if(isset($_POST['submit-user'])) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $password = wp_generate_password('12');
        //از pre برای امنیت استفاده می شود
        $userdata =
            [
                'user_login' => apply_filters('pre_user_login', $_POST['username']),
                'user_email' => apply_filters('pre_user_email', $_POST['user_email']),
                'user_pass' => apply_filters('pre_user_pass', $password),
            ];
        //ایدی هم برمیگردونه
        $user_id = wp_insert_user($userdata);
        insert_user_meta($user_id,'_phone',$_POST['tel']);
    }
}