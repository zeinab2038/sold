<?php
//اپدیت کاربر
if(isset($_POST['update-user'])){
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $userdata =
            [
                'ID'=>$_POST['id'],
                'user_login'=>apply_filters('pre_user_login',$_POST['username']),
                'user_email'=>apply_filters('pre_user_email',$_POST['user_email']),
            ];
        $user = wp_update_user($userdata);
        insert_user_meta($user,'_phone',$_POST['tel']);
    }
}