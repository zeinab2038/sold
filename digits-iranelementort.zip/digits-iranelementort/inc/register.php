<?php
add_action('wp_ajax_nopriv_wp_ls_auth_send_verification_code', 'wp_ls_auth_send_verification_code');
add_action('wp_ajax_nopriv_wp_ls_auth_verify_verification_code', 'wp_ls_auth_verify_verification_code');
add_action('wp_ajax_nopriv_wp_lr_register_user', 'wp_lr_register_user');
function wp_ls_auth_send_verification_code(){
if(isset($_POST['_nonce']) && !wp_verify_nonce($_POST['_nonce'])){
	die('access denided');
}
	$user_phone=sanitize_text_field($_POST['user_phone']);
	wp_lr_validate_phone($user_phone);
	$verification_code='123456';
	wp_ls_send_sms($verification_code,$user_phone,'122865');
    wp_lr_add_verification_code_phone($user_phone,$verification_code);
}
function wp_lr_validate_phone($phone){
	if (!preg_match('/^(00|09|\+)[0-9]{8,12}$/', $phone)) {
		wp_send_json([
			'error' => true,
			'message' => 'لطفا شماره موبایل معتبر وارد نمایید!'
		], 403);
	}
}
function wp_ls_auth_verify_verification_code(){
	if(isset($_POST['_nonce']) && !wp_verify_nonce($_POST['_nonce'])){
		die('access denided');
	}
	$verification_code=sanitize_text_field($_POST['verification_code']);
	wp_lr_validae_veridication_code($verification_code);
    wp_lr_check_user_verification_code($verification_code);
}
function wp_lr_validae_veridication_code($verification_code){
	if($verification_code=''){
		wp_send_json([
			'error' => true,
			'message' => 'لطفا کد تاییده را وارد نمایید'
		], 403);
	}
	if($verification_code==6){
		wp_send_json([
			'error' => true,
			'message' => 'کد شما باید شامل 6 حرف باشد'
		], 403);
	}
}
function wp_lr_check_user_verification_code($verification_code){
 global $wpdb;
 $table= $wpdb->prefix.'sl_lr_sms_verify_code';
	$stmt = $wpdb->get_row($wpdb->prepare("SELECT verification_code,phone FROM {$table} WHERE verification_code ='%s'", $verification_code));
	if ($stmt) {
        $_SESSION['currect_user_phone']=$stmt->phone;
	} else {
		wp_send_json([
			'error' => true,
			'message' => 'کد تاییدیه معتبر نمی باشد'
		], 403);
	}
}
function wp_lr_register_user(){
	if(isset($_POST['_nonce']) && !wp_verify_nonce($_POST['_nonce'])){
		die('access denided');
	}
	p_lr_validate_user_register($_POST);
    $display_name=explode('@',$_POST['email']);
    $user_login = explode('@', $_POST['email']);
    $user_login = $user_login[0] . rand(10, 99);
    $user_name_family = explode(' ', $_POST['display_name']);
    $data = [
        'user_login' => apply_filters('pre_user_login', sanitize_text_field($user_login)),
        'user_pass' => apply_filters('pre_user_pass', sanitize_text_field($_POST['password'])),
        'first_name' => apply_filters('pre_user_first_name', sanitize_text_field($user_name_family[0])),
        'last_name' => apply_filters('pre_user_last_name', sanitize_text_field($user_name_family[1])),
        'user_email' => apply_filters('pre_user_email', sanitize_text_field($_POST['email'])),
    ];
    $user_id=wp_insert_user($data);
    add_user_meta($user_id,'_lr_user_phone_', $_SESSION['currect_user_phone']);
    unset($_SESSION[currect_user_phone]);
    if(!is_wp_error($user_id)){
        wp_send_json([
            'error' => true,
            'message' => 'ثبت نام با موفقیت بود'
        ], 403);
        wp_send_json([
            'error' => true,
            'message' => 'خطایی رخ داده است'
        ], 403);
    }
}
function p_lr_validate_user_register($data){
    if(email_exist($data['email'])){
        wp_send_json([
            'error' => true,
            'message' => 'این ایمیل قبلا ثبت شده است'
        ], 403);
    }
	if($data['display_name']==''){
		wp_send_json([
			'error' => true,
			'message' => 'لطفا نام خانوادگی را وارد نمایید'
		], 403);
	}
	if($data['email']==''){
		wp_send_json([
			'error' => true,
			'message' => 'لطفا ایمیل را وارد نمایید'
		], 403);
	}
	if($data['password']==''){
		wp_send_json([
			'error' => true,
			'message' => 'لطفا رمزعبور را وارد نمایید'
		], 403);
	}
	if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%^&*])(?=.{8,})/', $data['password'])) {
		wp_send_json([
			'error' => true,
			'message' => 'کلمه عبور باید شامل حداقل 8 کارکتر و ترکیبی از حروف کوچک, بزرگ, اعداد و کارکترهای ویژه باشد!'
		], 403);
	}
}