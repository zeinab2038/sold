<?php
add_action('wp_ajax_nopriv_wp_ls_auth_send_verification_code','wp_ls_auth_send_verification_code');
add_action('wp_ajax_nopriv_wp_ls_auth_verify_verification_code','wp_ls_auth_verify_verification_code');
function wp_ls_auth_send_verification_code(){
if(isset($_POST['_nonce']) && !wp_verify_nonce($_POST['_nonce'])){
	die('access denided');
}
	$user_phone=sanitize_text_field($_POST['user_phone']);
	wp_lr_validate_phone($user_phone);
	$verification_code=rand(1000,9999);
	$bodyid='12365';
	wp_ls_send_sms($verification_code,$user_phone,$bodyid);
	wp_lr_add_verification_code_phone($user_phone,$verification_code);
}
function wp_lr_validate_phone($phone){
	if (!preg_match('/^(00|09|\+)[0-9]{8,12}$/', $phone)) {
		wp_send_json([
			'error' => true,
			'message' => 'لطفا شماره موبایل معتبر وارد نمایید!'
		], 403);
	}
}
function wp_ls_auth_verify_verification_code(){
	if(isset($_POST['_nonce']) && !wp_verify_nonce($_POST['_nonce'])){
		die('access denided');
	}
	$verification_code=sanitize_text_field($_POST['verification_code']);
	wp_lr_validae_veridication_code($verification_code);
}
function wp_lr_validae_veridication_code($verification_code){
	if($verification_code=''){
		wp_send_json([
			'error' => true,
			'message' => 'لطفا کد تاییده را وارد نمایید'
		], 403);
	}
	if($verification_code<6){
		wp_send_json([
			'error' => true,
			'message' => 'کد شما باید شامل 6 حرف باشد'
		], 403);
	}
}
function wp_lr_check_user_verification_code($verification_code){

}