<?php
/**
 * Plugin Name: PowerPack Pro for Elementor
 * Plugin URI: https://iranelEmentor.com
 * Description: Extend Elementor Page Builder with 70+ Creative Widgets and exciting extensions.
 * Version: 2.9.20
 * Author: iranelEmentor
 * Author URI: http://iranelEmentor.com
 * License: GNU General Public License v2.0
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: powerpack
 * Domain Path: /languages
 * Elementor tested up to: 3.14.0
 * Elementor Pro tested up to: 3.14.0
 */
defined('ABSPATH') || exit;
define('LR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LR_PLUGIN_URL', plugin_dir_url(__FILE__));
function wp_lr_register_assets() {
//css
	wp_register_style( 'lr-slick-style', LR_PLUGIN_URL . 'assets/css/front/slick.css', '', '1.0.0' );
	wp_register_style( 'lr-slick-theme-style', LR_PLUGIN_URL . 'assets/css/front/slick-theme.css', '', '1.0.0' );
	wp_register_style( 'lr-toast', LR_PLUGIN_URL . 'assets/css/front/jquery.toast.css', '', '1.0.0' );
	wp_register_style( 'lr-style', LR_PLUGIN_URL . 'assets/css/front/style.css', '', '1.0.0' );
	wp_enqueue_style( 'lr-slick-style' );
	wp_enqueue_style( 'lr-slick-theme-style' );
	wp_enqueue_style( 'lr-toast' );
	wp_enqueue_style( 'lr-style' );

//JS
	wp_register_script('toast-js', LR_PLUGIN_URL . 'assets/js/front/jquery.toast.js', ['jquery'], '1.0.0', 'true');
	wp_register_script('slick-js', LR_PLUGIN_URL . 'assets/js/front/slick.js', ['jquery'], '1.0.0', 'true');
	wp_register_script('lr-main-js', LR_PLUGIN_URL . 'assets/js/front/main.js', ['jquery'], '1.0.0', 'true');

	wp_enqueue_script('lr-ajax-js', LR_PLUGIN_URL . 'assets/js/front/ajax.js', ['jquery'], '1.0.0', 'true');
	wp_localize_script('lr-ajax-js', 'lr_ajax', [
		'ajaxurl' => admin_url('admin-ajax.php'),
		'_nonce' => wp_create_nonce()
	]);
	wp_enqueue_script('toast-js');
	wp_enqueue_script('slick-js');
	wp_enqueue_script('lr-main-js');
}
function wp_lr_register_assets_admin()
{
	//CSS
	wp_register_style('lr-slick-style', LR_PLUGIN_URL . 'assets/css/front/slick.css', '', '1.0.0');
	wp_register_style('lr-slick-theme-style', LR_PLUGIN_URL . 'assets/css/front/slick-theme.css', '', '1.0.0');
	wp_register_style('lr-toast', LR_PLUGIN_URL . 'assets/css/front/jquery.toast.css', '', '1.0.0');
	wp_register_style('lr-style', LR_PLUGIN_URL . 'assets/css/front/style.css', '', '1.0.0');
	wp_enqueue_style('lr-slick-style');
	wp_enqueue_style('lr-slick-theme-style');
	wp_enqueue_style('lr-toast');
	wp_enqueue_style('lr-style');
	//JS
	wp_register_script('lr_admin_main-js', LR_PLUGIN_URL . 'assets/js/admin/admin.js', ['jquery'], '1.0.0', 'true');
	wp_enqueue_script('lr_admin_main-js');
}
add_action('wp_enqueue_scripts', 'wp_lr_register_assets');
add_action('admin_enqueue_scripts', 'wp_lr_register_assets_admin');

//include file
include_once 'inc/sendSms.php';
include 'registration.php';
include_once 'inc/register.php';
include_once 'inc/sms-functions.php';


