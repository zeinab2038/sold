jQuery(document).ready(function($){
    $('body').on('click','#send_code',function(e){
        e.preventDefault();
        let el = $(this);
        let user_phone=$('.user_phone').val();
        $.ajax({
            url: lr_ajax.ajaxurl,
            type: "POST",
            dataType: "JSON",
            data: {
                action: "wp_ls_auth_send_verification_code",
                user_phone: user_phone ,
                _nonce: lr_ajax._nonce
            },
            beforeSend: function () {
             },
            success: function (response) {
                $('#user_phone_number').hide();
                $('#verification_code').show();
                el.attr('id','verify_code');
                el.text('اعتبارسنجی کد تایید');
            },
            error: function (error) {
            if(error.responseJSON.error){
            alert(error.responseJSON.message)
}
            },
            complete: function () {
            },
        });
    });
    $('body').on('click','#verify_code',function(e){
        e.preventDefault();
        let el = $(this);
        let verification_code = $('.verification_code').val();
        $.ajax({
            url: lr_ajax.ajaxurl,
            type: "POST",
            dataType: "JSON",
            data: {
                action: "wp_ls_auth_verify_verification_code",
                verification_code: verification_code ,
                _nonce: lr_ajax._nonce
            },
            beforeSend: function () {
            },
            success: function (response) {

            },
            error: function (error) {
                if(error.responseJSON.error){
                    alert(error.responseJSON.message)
                }
            },
            complete: function () {
            },
        });
    });
})