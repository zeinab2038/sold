<?php
$user=get_user_by('id',$_GET['id']); ?>

<h1>ویرایش کاربر</h1>
<form action="<?php echo esc_url($_SERVER['PHP_SELF'].'?page=list_user&action=update&id='.$_GET['id'])?>" method="post">
    <input type="text" name="username" value="<?php echo $user->user_login ?>" placeholder="نام کاربری" >
    <input type="email" name="email" placeholder="ایمیل" value="<?php echo $user->user_email ?>">
    <input type="text" name="role" placeholder="نوع کاربر">
    <input type="submit" value="ویرایش" name="submit">

</form>
