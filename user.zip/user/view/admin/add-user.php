<h1>افزودن کاربر</h1>
<form action="<?php echo esc_url($_SERVER['PHP_SELF'])?>" method="post">
    <input type="text" name="username" placeholder="نام کاربری">
    <input type="email" name="email" placeholder="ایمیل">
    <input type="tel" name="tel" placeholder="شماره تلفن">
    <input type="text" name="role" placeholder="نوع کاربر">
    <input type="submit" value="افزودن" name="submit">

</form>
