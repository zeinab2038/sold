<!doctype html>
<html lang="fa">
<h1>فایل آپلودر</h1>
<div style="width: 100%;height: 100%;background-color: #fff;padding: 3px">
    <form action="" method="post">
        <textarea style="width: 100%" name="filter_word" id="" rows="10"
                  placeholder="کلماتی که تصمیم دارید به لینک  تبدیل شوند را وارد نمایید و آنها را با کاما ( , ) از هم جدا نمایید">s</textarea>
        <input type="submit" name="btn-submit" value="ذخیره" style="margin-top: 20px;">
    </form>
</div>
