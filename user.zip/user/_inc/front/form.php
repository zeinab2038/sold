<?php
//ایجاد کاربر جدید
function create_new_user(){
	// پسوورد
	$password=wp_generate_password('12');
	create_new_user('vadid','$password','zseinab@gmail.com');
}
//گرفتن کاربران

add_action('create-user','create_new_user');