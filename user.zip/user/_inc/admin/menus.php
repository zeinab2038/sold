<?php
//var_dump(count_users());
add_action('admin_menu', 'wl_register_menus');

function wl_register_menus()
{
	add_menu_page(
		'مدیریت کاربران',
		'مدیریت کاربران',
		'manage_options',
		'wl_home',
		'manage_user',
	);
	add_submenu_page(
		'wl_home',
		'لیست کاربران',
		'لیست کاربران',
		'manage_options',
		'list_user',
		'list_user',
	);
    add_submenu_page(
        'wl_home', 'htc,nk
        
        ',
        'لیست کاربران',
        'manage_options',
        'list_user',
        'list_user',
    );

}

function list_user(): void
{
?>
<div class="wrap">
    <h1>لیست کاربران</h1>
    <table>
        <thead>
        <tr>
            <th>آی دی</th>
            <th>نام کاربری</th>
            <th>ایمیل</th>
            <th>نام نمایشی</th>
            <th>تلفن</th>
            <th>عملیات</th>

        </tr>
        <tbody>
        <?php
$users=get_users();
foreach ($users as $user):

        ?>
        ?>
        <tr>
            <td><?php echo $user->ID ?></td>
            <td><?php echo $user->user_login ?></td>
            <td><?php echo $user->user_email ?></td>
            <td><?php echo $user->display_name ?></td>
            <td><?php echo get_user_meta($user->ID,'_phone',true) ?></td>
            <td><a href="<?php  echo $_SERVER['REQUEST_URI'].'&action=update'.'&id='.$user->ID ?>" class="dashicons dashicons-edit"></a>
                <a href="<?php echo $_SERVER['REQUEST_URI'].'&action=delete&'.'id='.$user->ID ?> " class="dashicons dashicons-trash"></a>
            </td>
        </tr>
<?php endforeach; ?>
        </tbody>
        </thead>
    </table>
</div>

<?php
    //حذف کاربر
    if(isset($_GET['action']) && isset($_GET['id'])){
        switch ($_GET['action']){
            case 'delete':
                $del_user=wp_delete_user($_GET['id']);
                if($del_user){
                    //ریدایرکت
                    wp_redirect(admin_url(''));
        }
                break;
            case 'update':
                include WL_PLUGIN_VIEW.'admin/update-user.php';
                include WL_PLUGIN_INC.'admin/update-user.php';

            }

        }

function manage_user(): void
{

}
    function create_user(): void
    {
        include WL_PLUGIN_VIEW.'admin/add-user.php';
        include WL_PLUGIN_INC.'admin/add-user.php';
}
}
