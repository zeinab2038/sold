<?php
if(isset($_POST['submit'])) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $password = wp_generate_password('12');
        //از pre برای امنیت استفاده می شود
        $userdata =
            [
                'user_login' => apply_filters('pre_user_login', $_POST['username']),
                'user_email' => apply_filters('pre_user_email', $_POST['email']),
                'user_pass' => apply_filters('pre_user_pass', $password)
            ];
        //ایدی هم برمیگردونه
        $user_id = wp_insert_user($userdata);
        update_user_meta($_POST['id'],'_phone',$_POST['tel']);
    }
}
