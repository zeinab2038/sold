<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Task manager UI</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<!-- partial:index.partial.html -->
<div class="page">
  <div class="pageHeader">
    <div class="title">Dashboard</div>
    <div class="userPanel"><i class="fa fa-chevron-down"></i><span class="username"><?=getLoggedInUser()->name ?> </span><img src="https://s3.amazonaws.com/uifaces/faces/twitter/kolage/73.jpg" width="40" height="40"/></div>
  </div>
  <div class="main">
    <div class="nav">
      <div class="searchbox">
        <div><i class="fa fa-search"></i>
          <input type="search" placeholder="Search"/>
        </div>
      </div>
      <div class="menu">
        <div class="title">Folder</div>
        <ul class="folder_List">
        <li class="active"> 
        <a href="<?= "../main/aaa.php" ?>"><i class="fa fa-folder"></i>All</a>
          <!--اضافه و حذف فولدر های دیتابیس-->
          <?php foreach($folders as $folder): ?>
          <li class="<?($_GET['folder_id']==$folder->id) ? 'active': '' ?>">
            <a href="?folder_id=<?= $folder->id ?>"> <i class="fa fa-folder"></i><?= $folder->name ?></a>
          <a href="?delete_folder=<?= $folder->id ?>"> x </a>
        </li>
          <?php endforeach; ?>
           
        </ul>
      </div>
      <input type="text" id="addFolderInput" placeholder="Add New folder">
      <button id="addFolderBtn">+</button>
    </div>
    <div class="view">
      <div class="viewHeader">
      <input type="text" id="addTaskInput" placeholder="Add New task">
    
        <div class="functions">
          <div class="butt
          on active">Add New Task</div>
          <div class="button">Completed</div>
          <div class="button inverz"><i class="fa fa-trash-o"></i></div>
        </div>
      </div>
      <div class="content">
        <div class="list">
          <div class="title">Today</div>
          <ul>
          
          <?php foreach ($task as $tasks): ?>
            <li class="<?=$tasks->is_done ? 'checked' : '';?>">
            <i class="fa <?= $tasks->is_done  ? ' fa-check-square-o' : 'fa-square-o';?>"></i>
            <span><?=$tasks->title?></span>
              <div class="info">
             <span>Created at <span><?=$tasks->created_at?></span>
                <a href="?delete_task=<?= $tasks->id ?>" class="remove" onclick="return confrim('are you delete this folder؟')"> x </a>
              </div>
            </li>
            <?php endforeach; ?>
          </ul>
        </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- partial -->
  <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script  src="../assets/js/script.js"></script>
       <script>
$(document).ready(function(){
$('#addFolderBtn').click(function(e){
  var input=$('#addFolderInput');
  $.ajax({
    url:"../process/ajaxHandler.php",
    method:"post",
    data:{action: "addFolder", folderName : input.val()},
    success:function(response){
      if(response=='1'){
$('<li><a href="#"><i class="fa fa-folder"></i>'+input.val()+'</a></li>').appendTo('.folder_List')
      }
      alert(response);
    }
  });
});
});
$('#addTaskInput').on("keypress",function(e){
if (e.keyCode ==13) {
    $.ajax({
    url:"../process/ajaxHandler.php",
    method:"post",
    data:{action: "addTask",  folderId: <?= $_GET['folder_id'] ?? 0 ?>, TitleTask : $('#addTaskInput').val()},
    success:function(response){
    alert(response);
    if(response=='1'){
      location.reload();
      }else{
        alert(response);
      }
     
    }
  });
  }
  //انتخاب ییش فرض
  $('#addTaskInput').focus();
});

  </script>   
</body>
</html>
