<?php
include "../bootstrap/init.php";

//ایا فرم ارسال شده؟
if($_SERVER['REQUEST_METHOD']=='POST'){
	$action=$_GET['action'];
	$param= $_POST;
	if($action=='register'){
		$result = register($param);
		if(!$result){
			echo "erroe";
		}
	}
	else if($action=='Login'){
$result= login($param['email'] , $param['password']);
if(!$result){
	echo "error";
}
else
{
	echo "success";
}
	}
	
}
include "../tpl/tpl-auth.php";