<?php
include "../bootstrap/init.php";

if(isset($_GET['delete_folder']) && is_numeric($_GET['delete_folder'])){
    $deledcount= deleteFolder($_GET['delete_folder']);
    //echo "$deledcount";
} 
if(!isLoggedIn()){
    header("Location: http://localhost/todolist/main/auth.php");
}
if(isset($_GET['delete_task']) && is_numeric($_GET['delete_task'])){
    $deletetask=deleteTask($_GET['delete_task']);
}
$folders=getFolder();
$task=getTask();
include "../tpl/tpl-index.php";