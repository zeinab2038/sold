<?php

function find_emails($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($ch);
    $emails = [];

    if ($output === false) {
        echo 'Error: ' . curl_error($ch);
    } else {
        preg_match_all('/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/', $output, $matches);
        $emails = $matches[0];
    }

    curl_close($ch);

    return $emails;
}

$emails = find_emails('https://iranelementor.com');

foreach ($emails as $email) {
    echo $email . "\n";
}