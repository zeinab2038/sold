<?php
include_once "../bootstrap/init.php";
//فقط ajax را قبول می کند
if(!isAjaxReques()){
    die("Invalid");
}
switch($_POST['action']){
    case "doneToggle":
        $task_id=$_POST['taskId'];
        doneSwith($task_id);
    case "addFolder":
       echo addFolder($_POST['folderName'],$folder);
        break;
        case "addTask":
            $folderId = $_POST['folderId'];
            $TitleTask = $_POST['TitleTask'];
            if(!isset($folderId) || empty($folderId)){
                echo "فولدر را انتخاب کنید.";
                die();
            }
            echo addTask($TitleTask,$folderId);      
}