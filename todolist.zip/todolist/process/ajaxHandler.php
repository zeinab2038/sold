<?php
include_once "../bootstrap/init.php";
//فقط ajax را قبول می کند
if(!isAjaxReques()){
    die("Invalid");
}
switch($_POST['action']){
    case "addFolder":
        if(!isset($_POST['folderName']) || strlen($_POST['folderName'])<3){
            echo "نام باید بزرگ تر از دو حرف باشد";
            die();
        }
        $folder=$pdo->lastInsertId()++;
       echo addFolder($_POST['folderName'],$folder);
        break;
        case "addTask":
            $folderId = $_POST['folderId'];
            $TitleTask = $_POST['TitleTask'];
            if(!isset($folderId) || empty($folderId)){
                echo "فولدر را انتخاب کنید.";
                die();
            }
            echo addTask($TitleTask,$folderId);
        
}