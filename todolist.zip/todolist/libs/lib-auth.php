<?php
function getCurrenrUserId(){
    return getLoggedInUser()->id ?? 0;
}
function  Login($email,$pass){
	$user= getUserByEmail($email);
	if(is_null($user)){
		return false;
	} 
	else{
		$_SESSION['Login']=$user;
		setcookie("login", $_SESSION['Login'],time() + 3600);
		return true;
	}
//چک کردن پسوورد
if(password_verify($pass,$user->password)){
  return true;
	}

}
function  getUserByEmail($email){
global $db;
$sql="SELECT email FROM users WHERE email=:email ";
$stm=$db->prepare($sql);
$stm->execute([':email'=> $email]);
$record=$stm->fetchAll(PDO::FETCH_OBJ);
return $record[0] ?? null;
}
function  getUserByPass($pass){
	global $db;
	$sql="SELECT password  FROM users WHERE password=:pass ";
	$stm=$db->prepare($sql);
	$stm->execute([':pass'=> $pass]);
	$record=$stm->fetchAll(PDO::FETCH_OBJ);
	return $record[0] ?? null;
	}
function getLoggedInUser(){
    return $_SESSION['login'] ?? null ;
	return setcookie("login", $_SESSION['login'] ,time() + 3600);
}
function isLoggedIn(){
    if (isset($_SESSION['Login'])) {
		return true;
    }
	else
	return false;
}
  
function register($userData){
	global $db;
	$sql="INSERT INTO users(name,email,password) VALUES(:name,:email,:password)";
	$pass=password_hash($userData['password'],PASSWORD_BCRYPT);
	$tmp= $db->prepare($sql);
	$tmp->execute([':name'=> $userData['username'],':email'=>$userData['email'],':password'=>$pass]);
	//تعداد اضافه شده را برمیگرداند
	return $tmp->rowCount() ? true : false;
}