<?php
 function getFolder(){
        global $db;
        $sql="SELECT * from folders ";
       $tmp= $db->prepare($sql);
       $tmp->execute();
       $record= $tmp->fetchAll(PDO::FETCH_OBJ);   
       return $record;
    }
    function deleteFolder($folder_id){
      global $db;
      $sql="DELETE from folders where id = $folder_id";
     $tmp= $db->prepare($sql);
     $tmp->execute();
     //تعداد حذف شده ها را برمیگرداند
     return $tmp->rowCount();

  }
  function addFolder($folder_name,$folder_id){
   global $db;
  $sql="INSERT INTO folders(name,id) values(:folder_name,:folder_id)";
  $tmp= $db->prepare($sql);
  $tmp->execute([':folder_name'=> $folder_name,':folder_id'=>$folder_id]);
  //تعداد اضافه شده را برمیگرداند
  return $tmp->rowCount();
}
function doneSwith($task_id){
  global $pdo;
  $current_user_id = getCurrenrUserId();
  $sql = "UPDATE task set is_done = 1 - is_done where user_id = :userID and id = :taskID";
  $stmt = $pdo->prepare($sql);
  $stmt->execute([':taskID'=>$task_id,':userID'=>$current_user_id]);
  return $stmt->rowCount();
}
function getTask(){
global $db;
$folder=$_GET['folder_id'] ?? 0;
$folder=(int)$folder;
$folderCondition='';
if(isset($_GET['folder_id'])){
  $folderCondition = " where folder_id=$folder";
}
$sql ="SELECT * from task $folderCondition ";
$tmp= $db->prepare($sql);
$tmp->execute();
$record= $tmp->fetchAll(PDO::FETCH_OBJ);   
return $record;
}
 
function addTask($TitleTask,$folder_id){
  global $db;
 $sql="INSERT INTO task(title, folder_id) values(:title,:folder_id)";
 $tmp= $db->prepare($sql);
 $tmp->execute([':title'=>$TitleTask,':folder_id'=>$folder_id]);
 //تعداد حذف شده ها را برمیگرداند
 return $tmp->rowCount();
}
function deleteTask($folder_id){
  global $db;
  $sql="DELETE from task where id = $folder_id";
 $tmp= $db->prepare($sql);
 $tmp->execute();
 //تعداد حذف شده ها را برمیگرداند
 return $tmp->rowCount();

}
